//! Edge flags (soft, smooth, hidden) and face orientation helpers.

use rustc_hash::FxHashMap;
use std::collections::{BTreeSet, VecDeque};

use rysmo_math::DVec3;

use crate::ids::{EdgeId, FaceId, VertexId};
use crate::mesh::{Mesh, key};

/// Shading normals by (face, vertex) corner.
pub type SmoothNormals = FxHashMap<(FaceId, VertexId), DVec3>;

impl Mesh {
    pub fn paint_edge(&mut self, id: EdgeId, material: Option<crate::MaterialId>) -> Result<(), crate::MeshError> {
        let edge = self.edges.get_mut(&id).ok_or(crate::MeshError::Missing(id.0))?;
        edge.material = material;
        Ok(())
    }

    /// Sets edge flags. `None` leaves a flag as it is.
    pub fn set_edge_flags(&mut self, edges: &[EdgeId], soft: Option<bool>, smooth: Option<bool>, hidden: Option<bool>) {
        for e in edges {
            if let Some(edge) = self.edges.get_mut(e) {
                if let Some(s) = soft {
                    edge.soft = s;
                }
                if let Some(s) = smooth {
                    edge.smooth = s;
                }
                if let Some(h) = hidden {
                    edge.hidden = h;
                }
            }
        }
    }

    /// The angle in degrees between the normals of the two faces along an edge, or
    /// `None` unless exactly two faces meet there.
    pub fn edge_angle(&self, e: EdgeId) -> Option<f64> {
        let faces = self.faces_of_edge(e);
        if faces.len() != 2 {
            return None;
        }
        let a = self.face_normal(faces[0])?;
        let b = self.face_normal(faces[1])?;
        Some(a.dot(b).clamp(-1.0, 1.0).acos().to_degrees())
    }

    /// Softens and smooths the edges where the two faces meet at less than
    /// `max_degrees`, as Soften Edges does. Returns how many changed.
    pub fn soften_by_angle(&mut self, edges: &[EdgeId], max_degrees: f64) -> usize {
        let mut n = 0;
        for e in edges {
            if self.edge_angle(*e).is_some_and(|a| a > 1e-6 && a < max_degrees) {
                let edge = self.edges.get_mut(e).expect("edge with faces exists");
                if !edge.soft || !edge.smooth {
                    edge.soft = true;
                    edge.smooth = true;
                    n += 1;
                }
            }
        }
        n
    }

    /// Faces reachable from `seed` through edges shared by exactly two faces.
    pub fn connected_faces(&self, seed: FaceId) -> BTreeSet<FaceId> {
        let mut seen = BTreeSet::from([seed]);
        let mut queue = VecDeque::from([seed]);
        while let Some(f) = queue.pop_front() {
            for e in self.face_edges(f) {
                let fs = self.faces_of_edge(e);
                if fs.len() == 2 {
                    for g in fs {
                        if seen.insert(g) {
                            queue.push_back(g);
                        }
                    }
                }
            }
        }
        seen
    }

    /// Turns faces round so that each pair of neighbours in `faces` runs its shared
    /// edge in opposite directions, starting from `seed`, which keeps its facing.
    pub fn orient_from(&mut self, seed: FaceId, faces: &BTreeSet<FaceId>) {
        let mut done = BTreeSet::from([seed]);
        let mut queue = VecDeque::from([seed]);
        while let Some(f) = queue.pop_front() {
            let steps = self.faces[&f].loop_edges();
            for (a, b) in steps {
                let Some(e) = self.edge_between(a, b) else { continue };
                let fs = self.faces_of_edge(e);
                if fs.len() != 2 {
                    continue;
                }
                for g in fs {
                    if g == f || done.contains(&g) || !faces.contains(&g) {
                        continue;
                    }
                    let same_way = self.faces[&g].loop_edges().contains(&(a, b));
                    if same_way {
                        self.faces.get_mut(&g).expect("listed").reverse();
                    }
                    done.insert(g);
                    queue.push_back(g);
                }
            }
        }
    }

    /// The signed volume enclosed by faces: positive when they face outwards.
    pub fn signed_volume(&self, faces: &BTreeSet<FaceId>) -> f64 {
        let mut v = 0.0;
        for f in faces {
            for t in crate::triangulate_face(self, *f) {
                let (a, b, c) = (self.pos(t[0]), self.pos(t[1]), self.pos(t[2]));
                v += a.dot(b.cross(c)) / 6.0;
            }
        }
        v
    }

    /// Shading normals for every (face, vertex) corner: the average of the normals of
    /// the faces around the vertex that are joined to the face across smooth edges at
    /// that vertex. Corners with no smooth edge get the face normal. Built in one pass
    /// for the viewport.
    pub fn smooth_normals(&self) -> SmoothNormals {
        let smooth: BTreeSet<_> = self.edges.values().filter(|e| e.smooth).flat_map(|e| e.v).collect();
        if smooth.is_empty() {
            return FxHashMap::default();
        }
        self.smooth_normals_at(&self.view(), &smooth)
    }

    /// `smooth_normals` limited to the corners at `vertices`.
    pub fn smooth_normals_at(&self, view: &crate::MeshView, vertices: &BTreeSet<VertexId>) -> SmoothNormals {
        self.smooth_normals_using(vertices, |vertex| view.faces_at(self, vertex))
    }

    /// Allows a cooperative caller to supply incrementally collected face adjacency.
    pub fn smooth_normals_using(
        &self,
        vertices: &BTreeSet<VertexId>,
        mut faces_at: impl FnMut(VertexId) -> Vec<FaceId>,
    ) -> SmoothNormals {
        let mut out = FxHashMap::default();
        let mut normals: FxHashMap<FaceId, Option<DVec3>> = FxHashMap::default();
        for v in vertices {
            let smooth_here: Vec<_> = self
                .edges_of_vertex(*v)
                .into_iter()
                .filter(|e| self.edges[e].smooth)
                .map(|e| self.edges[&e].v)
                .map(|[a, b]| key(a, b))
                .collect();
            if smooth_here.is_empty() {
                continue;
            }
            let faces = faces_at(*v);
            // The edges at v along each face, as (position in faces, edge).
            let mut sides = Vec::new();
            for (at, id) in faces.iter().enumerate() {
                for ring in self.faces[id].loops() {
                    for (i, x) in ring.iter().enumerate() {
                        if x == v {
                            let before = ring[(i + ring.len() - 1) % ring.len()];
                            let after = ring[(i + 1) % ring.len()];
                            sides.extend([(at, key(before, *v)), (at, key(*v, after))]);
                        }
                    }
                }
            }
            // Union the faces at v that share a smooth edge at v.
            let mut group: Vec<usize> = (0..faces.len()).collect();
            let mut changed = false;
            for k in &smooth_here {
                let mut along: Vec<usize> = sides.iter().filter(|(_, side)| side == k).map(|(at, _)| *at).collect();
                along.dedup();
                if let [first, second] = along[..] {
                    let (ga, gb) = (group[first], group[second]);
                    if ga != gb {
                        for g in &mut group {
                            if *g == gb {
                                *g = ga;
                            }
                        }
                        changed = true;
                    }
                }
            }
            if !changed {
                continue;
            }
            let here: Vec<Option<DVec3>> =
                faces.iter().map(|f| *normals.entry(*f).or_insert_with(|| self.face_normal(*f))).collect();
            for (at, f) in faces.iter().enumerate() {
                let mates = group.iter().zip(&here).filter(|(g, _)| **g == group[at]);
                let sum: DVec3 = mates.filter_map(|(_, normal)| *normal).sum();
                if sum.length() > 1e-12 {
                    out.insert((*f, *v), sum.normalize());
                }
            }
        }
        out
    }
}
