#!/usr/bin/env bash
# Local Rust checks. Application unit tests
# exercise editor/UI state without opening a window or creating a GPU device.
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.."
if [[ $# -gt 1 || ( $# -eq 1 && "$1" != --offline ) ]]; then
    echo "Usage: scripts/check-rust.sh [--offline]" >&2
    exit 2
fi
cargo_options=(--locked)
if [[ $# -eq 1 ]]; then cargo_options+=(--offline); fi
export CARGO_BUILD_JOBS="${CARGO_BUILD_JOBS:-2}"
cargo fmt --all --check
cargo clippy --workspace --all-targets "${cargo_options[@]}" -- -D warnings
cargo test --lib -p rysmo_math -p rysmo_mesh -p rysmo_model -p rysmo_infer \
    -p rysmo_tools -p rysmo_io -p rysmo_mcp -p rysmo_library "${cargo_options[@]}"
# Exercise the real stdio binary and token-protected TCP bridge as well.
cargo test -p rysmo_mcp --test stdio --test live "${cargo_options[@]}"
# The portable profile avoids multi-gigabyte debug symbols in the linked app suite.
cargo test --lib -p rysmo_app --profile portable "${cargo_options[@]}"
cargo check -p rysmo_app --target wasm32-unknown-unknown --profile web-release "${cargo_options[@]}"
