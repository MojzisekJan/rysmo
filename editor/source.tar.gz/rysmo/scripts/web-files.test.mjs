import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";
import vm from "node:vm";
const source = await readFile(new URL("../crates/rysmo_app/src/web_files.js", import.meta.url), "utf8");
async function fixture({ diagnostics=false, embedded=false, pickerError=null, readError=false, cancelInput=false, diagnosticsPanel=null, storage=null, indexedDB=null }={}) {
  const calls={open:0,save:0,inputs:0,downloads:[],writes:[],attached:0,removed:0};
  const listeners = new Map();
  const window={addEventListener(type, callback){listeners.set(type, callback);},showOpenFilePicker:async()=>{calls.open++;if(pickerError)throw pickerError;return [{name:"picked.rysmo",getFile:async()=>({text:async()=>"model"})}];},showSaveFilePicker:async()=>{calls.save++;return {name:"saved.rysmo",queryPermission:async()=>"granted",createWritable:async()=>({write:async text=>calls.writes.push(text),close:async()=>{}})};}};
  window.top=embedded?{}:window;
  if (storage) window.localStorage = storage;
  const document={getElementById:()=>diagnosticsPanel,body:{appendChild(node){node.attached=true;calls.attached++;}},createElement(type){
    if(type==="input")return {style:{},files:[{name:"fixture.rysmo",size:4,arrayBuffer:async()=>{if(readError)throw Error("read failed");return Uint8Array.from([0,1,254,255]).buffer;},text:async()=>{if(readError)throw Error("read failed");return "fixture model";}}],remove(){calls.removed++;},click(){assert.equal(this.attached,true);calls.inputs++;queueMicrotask(()=>cancelInput?this.oncancel():this.onchange());}};
    if(type==="a")return {click(){calls.downloads.push(this.download);},remove(){}};
    throw Error(`Unexpected element ${type}`);
  }};
  const context=vm.createContext({window,document,location:{search:diagnostics ? "?diagnostics" : ""},URLSearchParams,performance:{now:()=>42},WebAssembly,indexedDB:indexedDB || {open(){throw Error("storage unavailable");}},console:{warn(){}},URL:{createObjectURL(){return "blob:test";},revokeObjectURL(){}},Blob,TextEncoder,Uint8Array,setTimeout(){},queueMicrotask});
  const module=new vm.SourceTextModule(source,{context});await module.link(()=>{});await module.evaluate();
  return {api:module.namespace,calls,window,listeners};
}
test("cross-origin embed opens via input even when storage is unavailable",async()=>{
  const {api,calls}=await fixture({embedded:true});
  assert.equal(JSON.stringify((await api.pick_open()).slice(0, 2)),JSON.stringify(["fixture.rysmo","fixture model"]));
  assert.equal(calls.open,0);assert.equal(calls.inputs,1);assert.equal(calls.attached,1);assert.equal(calls.removed,1);
});
test("blocked top-level picker falls back; user cancellation does not reopen it",async()=>{
  const blocked=await fixture({pickerError:Object.assign(Error("blocked"),{name:"SecurityError"})});
  assert.equal((await blocked.api.pick_open())[0],"fixture.rysmo");assert.equal(blocked.calls.inputs,1);
  const cancelled=await fixture({pickerError:Object.assign(Error("cancelled"),{name:"AbortError"})});
  assert.equal(await cancelled.api.pick_open(),null);assert.equal(cancelled.calls.inputs,0);
});
test("iframe Save downloads; top-level Save can still write the chosen file",async()=>{
  const embedded=await fixture({embedded:true});
  assert.equal((await embedded.api.save("model.rysmo","model",false))[1],"download");
  assert.equal(embedded.calls.save,0);assert.deepEqual(embedded.calls.downloads,["model.rysmo"]);
  const top=await fixture();assert.equal((await top.api.save("model.rysmo","model",false))[1],"picked");
  assert.deepEqual(top.calls.writes,["model"]);
});
test("failed input read completes without leaving an unresolved open operation",async()=>{
  const {api}=await fixture({embedded:true,readError:true});assert.equal(await api.pick_open(),null);
});

test("cancelled input removes the temporary picker",async()=>{
  const {api,calls}=await fixture({embedded:true,cancelInput:true});
  assert.equal(await api.pick_open(),null);
  assert.equal(calls.attached,1);assert.equal(calls.removed,1);
});
test("loader never displays more downloaded bytes than the served WASM size",async()=>{
  const status={textContent:""},fill={style:{}};
  const loading={classList:{remove(){}},querySelector:s=>s===".status"?status:fill};
  const loaderSource=await readFile(new URL("../crates/rysmo_app/loader.mjs",import.meta.url),"utf8");
  const context=vm.createContext({document:{getElementById:()=>loading,querySelector:()=>({href:"test.wasm"})},fetch:async()=>({headers:{get:()=>String(1048576)}})});
  const module=new vm.SourceTextModule(loaderSource,{context});await module.link(()=>{});await module.evaluate();
  const loader=module.namespace.default();loader.onStart();
  await new Promise(resolve=>setImmediate(resolve));
  loader.onProgress({current:2097152});
  assert.equal(status.textContent,"Downloading 1.0 of 1.0 MB");
  assert.equal(fill.style.width,"100%");
  loader.onSuccess();assert.equal(status.textContent,"Preparing the 3D view...");
});

test("renderer diagnostics update only the opt-in DOM panel",async()=>{
  const panel={dataset:{}};
  const enabled=await fixture({diagnosticsPanel:panel});
  enabled.api.set_render_diagnostics("Editor updates: 60 FPS");
  assert.equal(panel.dataset.editor,"Editor updates: 60 FPS");
  assert.ok(Number(panel.dataset.editorUpdated)>0);
  assert.equal(enabled.calls.open,0);assert.equal(enabled.calls.inputs,0);
  const disabled=await fixture();
  assert.doesNotThrow(()=>disabled.api.set_render_diagnostics("ignored"));
});

test("auto-save preferences persist, validate stored values, and tolerate blocked storage", async()=>{
  let stored = null;
  const storage = {getItem:()=>stored,setItem:(key,value)=>{assert.equal(key,"rysmo.autosave");stored=value;}};
  const {api} = await fixture({storage});
  assert.equal(JSON.stringify(api.get_autosave_settings()), "[true,1]");
  api.set_autosave_settings(false, 5);
  const reloaded = await fixture({storage});
  assert.equal(JSON.stringify(reloaded.api.get_autosave_settings()), "[false,5]");
  for (const invalid of ['oops', '{"enabled":true,"minutes":0}', '{"enabled":false,"minutes":999}', '{"enabled":true,"minutes":1.5}', '{"enabled":"false","minutes":5}']) {
    stored = invalid;
    assert.equal(JSON.stringify(api.get_autosave_settings()), "[true,1]");
  }
  const blocked = await fixture();
  assert.equal(JSON.stringify(blocked.api.get_autosave_settings()), "[true,1]");
  assert.doesNotThrow(()=>blocked.api.set_autosave_settings(true, 2));
});

test("packaged loader uses the optimized WASM size without another network request", async()=>{
  const status={textContent:""},fill={style:{}};
  const loading={classList:{remove(){}},querySelector:s=>s===".status"?status:fill};
  const loaderSource=await readFile(new URL("../crates/rysmo_app/loader.mjs",import.meta.url),"utf8");
  let requests=0;
  const context=vm.createContext({document:{getElementById:()=>loading,querySelector:s=>s.startsWith("meta")?{content:"1048576"}:{href:"test.wasm"}},fetch:async()=>{requests++;throw Error("Unexpected request");}});
  const module=new vm.SourceTextModule(loaderSource,{context});await module.link(()=>{});await module.evaluate();
  const loader=module.namespace.default();loader.onStart();loader.onProgress({current:524288});
  assert.equal(requests,0);
  assert.equal(status.textContent,"Downloading 0.5 of 1.0 MB");
  assert.equal(fill.style.width,"50%");
});

test("workspace preferences survive reload and report unavailable storage", async()=>{
  const values=new Map();
  const storage={getItem:key=>values.get(key)??null,setItem:(key,value)=>values.set(key,value)};
  const first=await fixture({storage});
  assert.equal(first.api.load_preferences(),null);
  const text=JSON.stringify({reverse_zoom:true,windows:{Inspector:[100,150,320,400]}});
  assert.equal(first.api.save_preferences(text),true);
  const second=await fixture({storage});
  assert.equal(second.api.load_preferences(),text);
  assert.equal(second.api.get_autosave_settings()[0],true);
  const blocked=await fixture({storage:{getItem(){throw Error("blocked")},setItem(){throw Error("blocked")}}});
  assert.equal(blocked.api.load_preferences(),null);
  assert.equal(blocked.api.save_preferences(text),false);
});


function recoveryDatabase({ aborts = 0, openFailures = 0, cloneValues = true, rejectWorkspaceHandles = false } = {}) {
  const stores = new Map(["state", "files", "handles"].map(name => [name, new Map()]));
  return { stores, open() {
    const request = {};
    queueMicrotask(() => {
      if (openFailures-- > 0) {
        request.error = Error("storage temporarily blocked");
        request.onerror();
        return;
      }
      request.result = {transaction(name, mode) {
        const transaction = {};
        transaction.objectStore = () => ({
          get(key) {
            const get = {};
            queueMicrotask(() => { get.result = stores.get(name).get(key); get.onsuccess(); });
            return get;
          },
          put(value, key) {
            assert.equal(mode, "readwrite");
            if (rejectWorkspaceHandles && key === "workspace" && value.documents.some(doc => doc.handle)) {
              throw Object.assign(Error("file handles cannot be cloned"), {name: "DataCloneError"});
            }
            queueMicrotask(() => {
              if (aborts-- > 0) { transaction.onabort(); return; }
              stores.get(name).set(key, cloneValues ? JSON.parse(JSON.stringify(value)) : value);
              transaction.oncomplete();
            });
          },
        });
        return transaction;
      }};
      request.onsuccess();
    });
    return request;
  }};
}

test("recovery acknowledges commits, restores dirty state and keeps the previous copy on abort", async () => {
  const db = recoveryDatabase();
  const { api } = await fixture({ indexedDB: db });
  assert.equal(await api.autosave("work.rysmo", "first", true), true);
  const restored = await api.restore();
  assert.equal(restored.current.name, "work.rysmo");
  assert.equal(restored.current.text, "first");
  assert.equal(restored.current.dirty, true);
  // This transaction aborts without an error event, as IndexedDB permits.
  const blocked = recoveryDatabase({ aborts: 1 });
  blocked.stores.get("state").set("current", {name: "older.rysmo", text: "old", dirty: true});
  const retry = await fixture({ indexedDB: blocked });
  assert.equal(await retry.api.autosave("work.rysmo", "new", true), false);
  assert.equal((await retry.api.restore()).current.text, "old");
  assert.equal(await retry.api.autosave("work.rysmo", "new", false), true);
  assert.equal((await retry.api.restore()).current.dirty, false);
});

test("a failed database open can recover on the next autosave attempt", async () => {
  const { api } = await fixture({ indexedDB: recoveryDatabase({openFailures: 1}) });
  assert.equal(await api.autosave("work.rysmo", "draft", true), false);
  assert.equal(await api.autosave("work.rysmo", "draft", true), true);
  assert.equal((await api.restore()).current.text, "draft");
});

test("beforeunload warns only while the document has unsaved changes", async () => {
  const { api, listeners } = await fixture();
  let prevented = 0;
  const event = {preventDefault(){prevented++;}};
  const unload = listeners.get("beforeunload");
  unload(event);
  assert.equal(prevented, 0);
  api.set_unsaved_changes(true);
  unload(event);
  assert.equal(prevented, 1);
  assert.equal(event.returnValue, "");
  api.set_unsaved_changes(false);
  unload(event);
  assert.equal(prevented, 1);
});

test("a Save As completing after New cannot attach its handle to the new document", async () => {
  const { api, window, calls } = await fixture();
  let finish;
  const gate = new Promise(resolve => { finish = resolve; });
  const handle = {name:"old.rysmo", queryPermission:async()=>"granted", createWritable:async()=>({write:async text=>calls.writes.push(text), close:async()=>{}})};
  let picks = 0;
  window.showSaveFilePicker = async () => { picks++; await gate; return handle; };
  const pending = api.save("old.rysmo", "old contents", true);
  api.forget_file();
  finish();
  assert.equal((await pending)[0], "old.rysmo");
  await api.save("new.rysmo", "new contents", false);
  assert.equal(picks, 2);
  assert.deepEqual(calls.writes, ["old contents", "new contents"]);
});

test("an in-place save keeps its original handle while another file is opened", async () => {
  const { api, window, calls } = await fixture();
  let release;
  const gate = new Promise(resolve => {release = resolve;});
  let writes = 0;
  const original = {name:"original.rysmo", queryPermission:async()=>"granted", createWritable:async()=>({write:async text=>{writes++; if(writes===2) await gate; calls.writes.push(text);},close:async()=>{}})};
  window.showSaveFilePicker = async () => original;
  await api.save("original.rysmo", "first", true);
  const pending = api.save("original.rysmo", "second", false);
  const opened = await api.pick_open();
  api.accept_open_file(opened[2]);
  release();
  assert.equal((await pending)[0], "original.rysmo");
  assert.equal(calls.downloads.length, 0);
  assert.deepEqual(calls.writes, ["first", "second"]);
});


test("restored handles are used only after the editor accepts the recovery model", async () => {
  let writes = 0;
  const handle = {name:"restored.rysmo", queryPermission:async()=>"granted", createWritable:async()=>({write:async()=>{writes++;},close:async()=>{}})};
  const db = recoveryDatabase();
  db.stores.get("state").set("current", {name:"restored.rysmo", text:"model", dirty:true});
  db.stores.get("handles").set("restored.rysmo", handle);
  const rejected = await fixture({indexedDB:db});
  await rejected.api.restore();
  assert.equal((await rejected.api.save("draft.rysmo", "draft", false))[1], "picked");
  assert.equal(writes, 0);
  const accepted = await fixture({indexedDB:db});
  const restored = await accepted.api.restore();
  accepted.api.accept_open_file(restored.token);
  assert.equal((await accepted.api.save("restored.rysmo", "updated", false))[1], "file");
  assert.equal(writes, 1);
});

test("a rejected Open keeps the previous file handle", async () => {
  const {api,window,calls} = await fixture();
  const handle = {name:"valid.rysmo", queryPermission:async()=>"granted", createWritable:async()=>({write:async text=>calls.writes.push(text),close:async()=>{}})};
  window.showSaveFilePicker = async () => handle;
  await api.save("valid.rysmo", "valid", true);
  const opened = await api.pick_open();
  // Parsing failed, so the editor rejects the staged handle.
  api.reject_open_file(opened[2]);
  assert.equal((await api.save("valid.rysmo", "still valid", false))[0], "valid.rysmo");
  assert.deepEqual(calls.writes, ["valid", "still valid"]);
});

test("overlapping Open results keep separate handles until accepted or rejected", async () => {
  const {api,window} = await fixture();
  const writes = [];
  let next = 0;
  window.showOpenFilePicker = async () => {
    const name = `file-${++next}.rysmo`;
    return [{name, getFile:async()=>({text:async()=>"model"}), queryPermission:async()=>"granted", createWritable:async()=>({write:async text=>writes.push([name,text]),close:async()=>{}})}];
  };
  const first = await api.pick_open();
  const second = await api.pick_open();
  assert.notEqual(first[2], second[2]);
  api.accept_open_file(first[2]);
  api.reject_open_file(second[2]);
  assert.equal((await api.save(first[0], "updated", false))[0], "file-1.rysmo");
  assert.deepEqual(writes, [["file-1.rysmo", "updated"]]);
});

test("binary import preserves bytes, handles cancellation and read failure, and respects size bounds",async()=>{
  const good=await fixture();const imported=await good.api.pick_data_file(".glb",64);
  assert.equal(imported[0],"fixture.rysmo");assert.deepEqual(Array.from(imported[1]),[0,1,254,255]);
  assert.equal(good.calls.removed,1);assert.equal(good.calls.open,0);
  const small=await fixture();assert.match((await small.api.pick_data_file(".glb",2)).error,/limit|large/i);
  const cancelled=await fixture({cancelInput:true});assert.equal(await cancelled.api.pick_data_file(".glb",64),null);
  const failed=await fixture({readError:true});assert.match((await failed.api.pick_data_file(".glb",64)).error,/read failed/);
});

test("document tabs retain distinct file destinations and Save As follows its initiating tab", async () => {
  const {api,window,calls}=await fixture();
  const handle=name=>({name,queryPermission:async()=>"granted",createWritable:async()=>({write:async text=>calls.writes.push(`${name}:${text}`),close:async()=>{}})});
  api.activate_document(1);
  window.showSaveFilePicker=async()=>handle("one.rysmo");
  await api.save("one.rysmo","one",true);
  api.activate_document(2);
  window.showSaveFilePicker=async()=>handle("two.rysmo");
  await api.save("two.rysmo","two",true);
  api.activate_document(1);
  await api.save("one.rysmo","one updated",false);
  let finish;
  const gate=new Promise(resolve=>{finish=resolve;});
  window.showSaveFilePicker=async()=>{await gate;return handle("renamed.rysmo");};
  const pending=api.save("renamed.rysmo","rename",true);
  api.activate_document(2);
  finish();await pending;
  await api.save("two.rysmo","two updated",false);
  api.activate_document(1);
  await api.save("renamed.rysmo","renamed updated",false);
  assert.deepEqual(calls.writes,["one.rysmo:one","two.rysmo:two","one.rysmo:one updated","renamed.rysmo:rename","two.rysmo:two updated","renamed.rysmo:renamed updated"]);
});

test("workspace recovery preserves all document snapshots, dirty flags and active tab", async()=>{
  const db=recoveryDatabase();
  const {api}=await fixture({indexedDB:db});
  const snapshot={active:2,documents:[{id:1,name:"A.rysmo",text:"model A",dirty:true},{id:2,name:"B.rysmo",text:"model B",dirty:false}]};
  assert.equal(await api.save_workspace(JSON.stringify(snapshot)),true);
  const reloaded=await fixture({indexedDB:db});
  const recovered=await reloaded.api.restore_workspace();
  assert.equal(recovered.active,2);
  assert.deepEqual(Array.from(recovered.documents,d=>[d.id,d.name,d.text,d.dirty]),[[1,"A.rysmo","model A",true],[2,"B.rysmo","model B",false]]);
  const first=api.save_workspace(JSON.stringify(snapshot));
  snapshot.documents.splice(0,1);
  const last=api.save_workspace(JSON.stringify(snapshot));
  await Promise.all([first,last]);
  assert.equal((await api.restore_workspace()).documents.length,1);
});

function deferred() {
  let resolve;
  const promise = new Promise(done => { resolve = done; });
  return { promise, resolve };
}
function fileHandle(name, writes) {
  return { name, queryPermission: async () => "granted", createWritable: async () => ({
    write: async text => writes.push(`${name}:${text}`), close: async () => {},
  }) };
}

test("overlapping saves commit in invocation order, including after a tab switch", async () => {
  const { api, window } = await fixture();
  const closing = deferred(), release = deferred();
  const committed = [];
  let writers = 0;
  const handle = { name: "model.rysmo", queryPermission: async () => "granted", createWritable: async () => {
    writers++;
    let content;
    return { write: async text => { content = text; }, close: async () => {
      if (content === "older") { closing.resolve(); await release.promise; }
      committed.push(content);
    }};
  }};
  api.activate_document(1);
  window.showSaveFilePicker = async () => handle;
  await api.save("model.rysmo", "initial", false);
  const first = api.save("model.rysmo", "older", false);
  await closing.promise;
  const second = api.save("model.rysmo", "newer", false);
  api.activate_document(2);
  await new Promise(resolve => setImmediate(resolve));
  assert.equal(writers, 2, "second save must not open an overlapping writer");
  release.resolve();
  await Promise.all([first, second]);
  assert.deepEqual(committed, ["initial", "older", "newer"]);
});

test("Save As follows A-B-A switches and queued Save uses the new destination", async () => {
  const { api, window } = await fixture();
  const writes = [];
  api.activate_document(1);
  window.showSaveFilePicker = async () => fileHandle("original.rysmo", writes);
  await api.save("original.rysmo", "initial", false);
  const picked = deferred();
  window.showSaveFilePicker = () => picked.promise;
  const rename = api.save("renamed.rysmo", "renamed", true);
  const update = api.save("original.rysmo", "latest", false);
  api.activate_document(2);
  api.activate_document(1);
  picked.resolve(fileHandle("renamed.rysmo", writes));
  await Promise.all([rename, update]);
  await api.save("renamed.rysmo", "next", false);
  assert.deepEqual(writes, ["original.rysmo:initial", "renamed.rysmo:renamed", "renamed.rysmo:latest", "renamed.rysmo:next"]);
});

test("cancelling Save As releases the queue and preserves the original destination", async () => {
  const { api, window } = await fixture();
  const writes = [];
  window.showSaveFilePicker = async () => fileHandle("original.rysmo", writes);
  await api.save("original.rysmo", "initial", false);
  const picked = deferred();
  window.showSaveFilePicker = () => picked.promise;
  const rename = api.save("renamed.rysmo", "rename", true);
  const update = api.save("original.rysmo", "latest", false);
  picked.resolve(Promise.reject(Object.assign(Error("cancelled"), { name: "AbortError" })));
  assert.equal(await rename, null);
  assert.equal((await update)[0], "original.rysmo");
  assert.deepEqual(writes, ["original.rysmo:initial", "original.rysmo:latest"]);
});

test("workspace recovery retains the collection and stores handles without save queues", async () => {
  const db = recoveryDatabase();
  const { api, window } = await fixture({ indexedDB: db });
  api.activate_document(1);
  window.showSaveFilePicker = async () => fileHandle("model.rysmo", []);
  await api.save("model.rysmo", "initial", false);
  const library = { collection: { name: "Parts", assets: [] }, modified: true };
  const snapshot = { active: 1, documents: [{id: 1, name: "model.rysmo", text: "model", dirty: false}], library };
  assert.equal(await api.save_workspace(JSON.stringify(snapshot)), true);
  const stored = db.stores.get("state").get("workspace");
  assert.equal(stored.documents[0].handle.name, "model.rysmo");
  assert.equal("writing" in stored.documents[0].handle, false);
  const reloaded = await fixture({ indexedDB: db });
  assert.deepEqual(JSON.parse(JSON.stringify((await reloaded.api.restore_workspace()).library)), library);
});

test("queued Save As opens its picker during the user gesture but writes after the earlier save", async () => {
  const { api, window } = await fixture();
  const blocked = deferred(), release = deferred();
  const writes = [];
  const first = fileHandle("first.rysmo", writes);
  first.createWritable = async () => ({ write: async text => {
    if (text === "earlier") { blocked.resolve(); await release.promise; }
    writes.push(`first.rysmo:${text}`);
  }, close: async () => {} });
  window.showSaveFilePicker = async () => first;
  await api.save("first.rysmo", "initial", false);
  const saving = api.save("first.rysmo", "earlier", false);
  await blocked.promise;
  let picked = false;
  window.showSaveFilePicker = async () => { picked = true; return fileHandle("renamed.rysmo", writes); };
  const renamed = api.save("renamed.rysmo", "latest", true);
  assert.equal(picked, true);
  await new Promise(resolve => setImmediate(resolve));
  assert.deepEqual(writes, ["first.rysmo:initial"]);
  release.resolve();
  await Promise.all([saving, renamed]);
  assert.deepEqual(writes, ["first.rysmo:initial", "first.rysmo:earlier", "renamed.rysmo:latest"]);
});


test("performance diagnostics are opt-in, bounded and do not require GPU timing support", async () => {
  const normal = await fixture();
  normal.api.profile_sample("pointer_event", 2, 1n, 2n);
  assert.equal(normal.window.rysmoPerformance, undefined);
  const enabled = await fixture({diagnostics:true});
  for (let i=0; i<4100; i++) enabled.api.profile_sample("pointer_event", i, 1n, BigInt(i));
  const profile = enabled.window.rysmoPerformance;
  assert.equal(profile.samples.length,4096); assert.equal(profile.dropped,4);
  assert.equal(profile.samples.at(-1).revision,"4099");
  enabled.window.rysmoProfileGL = {getExtension:()=>null};
  enabled.api.profile_gpu_begin(); enabled.api.profile_gpu_assets(); enabled.api.profile_gpu_end();
  assert.equal(profile.gpu.supported,false);
  assert.equal(profile.samples.at(-1).stage,"render_cpu");
  assert.equal(enabled.calls.writes.length,0);
});


test("cold-load milestones survive the bounded frame sample ring", async () => {
  const {api,window}=await fixture({diagnostics:true});
  api.profile_sample("model_installed",0,7n,0n);
  for(let i=0;i<4200;i++)api.profile_sample("editor_update",0,7n,0n);
  assert.equal(window.rysmoPerformance.samples.length,4096);
  assert.equal(window.rysmoPerformance.milestones[0].stage,"model_installed");
  assert.equal(window.rysmoPerformance.milestones[0].generation,"7");
});

test("split workspace transport preserves exact text, handles and queued snapshots", async () => {
  const db = recoveryDatabase();
  const { api, window } = await fixture({ indexedDB: db });
  api.activate_document(1);
  window.showSaveFilePicker = async () => fileHandle("one.rysmo", []);
  await api.save("one.rysmo", "initial", false);
  const metadata = { active: 1, documents: [
    { id: 1, name: "Žluťoučký.rysmo", dirty: true },
    { id: 2, name: "two.rysmo", dirty: false },
  ], library: { collection: { name: "Parts", assets: [] }, modified: true } };
  const texts = ['{"text":"quotes \\" and Unicode 🦀"}\n\u0000', "second\nmodel"];
  const expected = texts.slice();
  const first = api.save_workspace_parts(JSON.stringify(metadata), texts);
  texts[0] = "mutated caller array";
  assert.equal(await first, true);
  const stored = db.stores.get("state").get("workspace");
  assert.equal(stored.documents[0].handle.name, "one.rysmo");
  assert.deepEqual(Array.from(stored.documents, doc => doc.text), expected);
  const reloaded = await fixture({ indexedDB: db });
  const recovered = await reloaded.api.restore_workspace();
  assert.deepEqual(Array.from(recovered.documents, doc => [doc.name, doc.text, doc.dirty]),
    [["Žluťoučký.rysmo", expected[0], true], ["two.rysmo", expected[1], false]]);
  assert.deepEqual(JSON.parse(JSON.stringify(recovered.library)), metadata.library);
  const earlier = api.save_workspace_parts(JSON.stringify(metadata), ["earlier", "second"]);
  metadata.documents.splice(1, 1);
  const later = api.save_workspace_parts(JSON.stringify(metadata), ["latest"]);
  assert.deepEqual(await Promise.all([earlier, later]), [true, true]);
  assert.deepEqual(Array.from((await api.restore_workspace()).documents, doc => doc.text), ["latest"]);
});

test("invalid split workspace payload cannot overwrite recovery", async () => {
  const db = recoveryDatabase();
  const { api } = await fixture({ indexedDB: db });
  const metadata = JSON.stringify({ active: 1, documents: [{id: 1, name: "saved.rysmo", dirty: true}] });
  assert.equal(await api.save_workspace_parts(metadata, ["keep"]), true);
  for (const [json, texts] of [
    ["{", []], ["null", []], ["{}", []], [metadata, []], [metadata, [null]],
    [metadata, [1]], [metadata, "text"], [metadata, Array(1)],
    [JSON.stringify({documents:[null]}), ["text"]],
    [JSON.stringify({documents:[[]]}), ["text"]],
    [JSON.stringify({documents:Array(17).fill({id:1})}), Array(17).fill("text")],
  ]) assert.equal(await api.save_workspace_parts(json, texts), false);
  assert.equal((await api.restore_workspace()).documents[0].text, "keep");
});


test("manual workspace bridge benchmark", {skip: !process.env.RYSMO_RECOVERY_BENCH_MODEL}, async () => {
  const text = await readFile(process.env.RYSMO_RECOVERY_BENCH_MODEL, "utf8");
  // Keep storage outside this CPU proxy: no IndexedDB structured-clone claim.
  const {api} = await fixture({indexedDB: recoveryDatabase({cloneValues: false})});
  const metadata = {active: 1, documents: [{id: 1, name: "large.rysmo", dirty: true}]};
  const small = JSON.stringify(metadata);
  const joined = JSON.stringify({...metadata, documents: [{...metadata.documents[0], text}]});
  const results = [];
  for (const split of [false, true]) {
    const samples = [];
    for (let i = 0; i < 24; i++) {
      const start = performance.now();
      const success = await (split ? api.save_workspace_parts(small, [text]) : api.save_workspace(joined));
      const elapsed = performance.now() - start;
      assert.equal(success, true);
      if (i >= 3) samples.push(elapsed);
    }
    assert.equal((await api.restore_workspace()).documents[0].text, text);
    samples.sort((a,b) => a-b);
    results.push({split, median_ms:samples[10], p95_ms:samples[19], samples:21});
  }
  console.log("workspace-bridge-benchmark:", JSON.stringify({native_bytes:Buffer.byteLength(text), metadata_bytes:Buffer.byteLength(small), results}));
});


test("split workspace retries refused handles and reports failed transactions", async () => {
  const metadata = JSON.stringify({active: 1, documents: [{id: 1, name: "model.rysmo", dirty: true}]});
  const db = recoveryDatabase({rejectWorkspaceHandles: true});
  const {api, window} = await fixture({indexedDB: db});
  api.activate_document(1);
  window.showSaveFilePicker = async () => fileHandle("model.rysmo", []);
  await api.save("model.rysmo", "initial", false);
  assert.equal(await api.save_workspace_parts(metadata, ["recover me"]), true);
  const stored = db.stores.get("state").get("workspace");
  assert.equal(stored.documents[0].handle, null);
  assert.equal(stored.documents[0].text, "recover me");
  const failing = await fixture({indexedDB: recoveryDatabase({aborts: 1})});
  assert.equal(await failing.api.save_workspace_parts(metadata, ["failed"]), false);
  assert.equal(await failing.api.save_workspace_parts(metadata, ["retried"]), true);
  assert.equal((await failing.api.restore_workspace()).documents[0].text, "retried");
});
